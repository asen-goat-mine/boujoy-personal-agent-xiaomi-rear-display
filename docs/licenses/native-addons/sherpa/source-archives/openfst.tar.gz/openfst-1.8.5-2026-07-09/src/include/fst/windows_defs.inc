// Copyright 2005-2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the 'License');
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an 'AS IS' BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Aggregator file for common things that need to be defined when building
// for Windows.

#ifdef _WIN32
#include <basetsd.h>

// Python 3.8/3.9 on Windows defines ssize_t in pyconfig.h. Avoid redefining it
// when OpenFst headers are included from Python extension translation units.
#if !defined(Py_PYCONFIG_H) && !defined(HAVE_SSIZE_T) && \
    !defined(_SSIZE_T_) && !defined(_SSIZE_T_DEFINED)
using ssize_t = SSIZE_T;
#endif
#endif
